package humber.cpan205na.controller;

/**
 * Created by ivan on 11/11/15.
 */
public final class PublicUser extends UserClass {

    public PublicUser(String _userName) {
        super(_userName);
    }

}
