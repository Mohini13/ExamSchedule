package humber.cpan205na.controller.serverapi;

/**
 * Created by ivan on 12/11/15.
 */
public final class Exam {

}
