package humber.cpan205na.controller;

/**
 * Created by ivan on 16/11/15.
 */
public class ServletTable {

    // from ServletTable servlTab.name_forClass("humber.cpan205na.controller.serverapi.Course");
}
