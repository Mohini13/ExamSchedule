package humber.cpan205na.controller;

/**
 * Created by ivan on 12/11/15.
 */
public final class SessionTable {

    private String userName;
    private int sessionId;

    public SessionTable(String _userName, int _id) {
        userName = _userName;
        sessionId = _id;
    }

//    public

}
